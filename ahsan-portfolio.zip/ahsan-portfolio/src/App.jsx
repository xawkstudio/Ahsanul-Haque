import Nav from "./components/Nav.jsx";
import Hero from "./components/Hero.jsx";
import Work from "./components/Work.jsx";
import About from "./components/About.jsx";
import Footer from "./components/Footer.jsx";
export default function App() {
  return (
    <div className="wrap">
      <Nav /><Hero /><Work /><About /><Footer />
    </div>
  );
}
