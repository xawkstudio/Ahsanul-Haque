// ===== EDIT YOUR CONTENT HERE =====
export const PORTRAIT = "/ahsan.jpg"; // replace the file public/ahsan.jpg to change your photo

export const NAME = "Ahsanul Haque";

export const HERO = {
  heading: "Hi, I'm Ahsan",
  text: "I'm a motion designer and visual creator who loves turning ideas into movement. Every frame is a chance to tell a story, and I design mine with rhythm, clarity, and a lot of care.",
};

export const ABOUT = [
  "I'm Ahsanul Haque, a motion designer, graphic designer, and visual creator. I'm passionate about making visuals that grab attention and hold it.",
  "From motion graphics to brand visuals, I focus on meaningful storytelling: clean ideas, smooth movement, and details that make a piece feel finished.",
];

// To add a video: copy a line. `hash` is the ?h= value in the Vimeo embed URL; w/h are the video's proportions.
export const PROJECTS = [
  { id: "1231035775", hash: "cdd3a383c0", w: 1280, h: 1809, title: "Chonk" },
  { id: "1230649543", hash: "ec58a6e6f2", w: 1280, h: 1707, title: "Pr Rakhi break" },
  { id: "1161019115", hash: "9b1572b1f6", w: 1280, h: 1280, title: "Minimal Motion Graphics Promo" },
];
