import { NAME } from "../data.js";
export default function Footer() {
  const top = (e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: "smooth" }); };
  return (
    <footer>
      <span>© {new Date().getFullYear()} {NAME}</span>
      <a href="#top" onClick={top}>Back to top</a>
    </footer>
  );
}
