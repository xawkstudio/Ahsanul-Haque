import { NAME } from "../data.js";
export default function Nav() {
  return (
    <nav>
      <b>{NAME}</b>
      <div><a href="#work">Work</a><a href="#about">About</a></div>
    </nav>
  );
}
