export default function VideoCard({ id, hash, w, h, title }) {
  const src = `https://player.vimeo.com/video/${id}?h=${hash}&title=0&byline=0&portrait=0&dnt=1`;
  return (
    <div className="item">
      <div className="player" style={{ aspectRatio: `${w}/${h}` }}>
        <iframe
          src={src}
          title={title}
          allow="autoplay; fullscreen; picture-in-picture; clipboard-write"
          allowFullScreen
          referrerPolicy="strict-origin-when-cross-origin"
        />
      </div>
      <p>{title}</p>
    </div>
  );
}
