import { PROJECTS } from "../data.js";
import VideoCard from "./VideoCard.jsx";
export default function Work() {
  return (
    <section id="work">
      <div className="head"><h2>My Work</h2><span>Motion Graphics</span></div>
      <div className="grid">
        {PROJECTS.map((p) => <VideoCard key={p.id} {...p} />)}
      </div>
    </section>
  );
}
