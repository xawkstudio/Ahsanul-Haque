import { ABOUT, NAME, PORTRAIT } from "../data.js";
export default function About() {
  return (
    <section id="about" className="about">
      <div className="frame"><img src={PORTRAIT} alt={NAME} /></div>
      <div>
        <h2>About Me</h2>
        {ABOUT.map((t, i) => <p key={i}>{t}</p>)}
      </div>
    </section>
  );
}
