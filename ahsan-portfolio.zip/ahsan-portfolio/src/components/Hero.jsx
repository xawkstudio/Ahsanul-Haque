import { HERO, NAME, PORTRAIT } from "../data.js";
export default function Hero() {
  return (
    <header className="hero">
      <div>
        <h1>{HERO.heading}</h1>
        <p>{HERO.text}</p>
        <a className="btn" href="#work">See my work</a>
      </div>
      <div className="frame"><img src={PORTRAIT} alt={`Portrait of ${NAME}`} /></div>
    </header>
  );
}
